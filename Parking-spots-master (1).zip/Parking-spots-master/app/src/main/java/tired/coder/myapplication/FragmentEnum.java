package tired.coder.myapplication;

 public enum FragmentEnum {

        MapsFragment,LocationsFragment,NavigationStartFragment,NavigationFragment,UpdateProfileFragment;
 }
